// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

//#include "targetver.h"

#include <stdio.h>
#include <math.h>
#include <malloc.h>

void leg_initialize(char *name, int nmax);
double leg_forcol_pot (int nm, double x[]);
void leg_forcol_ac (int nm, double x[], double ac[]);



// TODO: reference additional headers your program requires here
